<?php 
include 'db_connect.php';
           //assign textbox to variable
	   $add_name=$_POST['name']; 
       $add_phone=$_POST['phone']; 
	   $add_email=$_POST['email']; 
	   $add_password=$_POST['password']; 
 
                //insert data
	   $query= "INSERT INTO admin(AdminName,AdminPhoneNum,AdminEmailAddress,AdminPassword) VALUES ('$add_name','$add_phone','$add_email','$add_password')" ;		
	   $result = mysqli_query( $link,$query) or die("Query failed");	// SQL statement for checking
         //checking either success or not
                 if ($result)
                 header("location:admin.php");	
		 
		else
		 echo "Problem occured !"; 	
	    mysqli_close($link);
?>