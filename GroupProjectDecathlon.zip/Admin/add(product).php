<?php 
include 'db_connect.php';
           //assign textbox to variable
	   $add_name=$_POST['name']; 
       $add_category=$_POST['category']; 
	   $add_price=$_POST['price']; 
	   $add_quantity=$_POST['quantity']; 
	   $add_image=$_POST['image'];
	   $add_date=$_POST['date'];
 
                //insert data
	   $query= "INSERT INTO product(ProductName,ProductCategory,ProductPrice,ProductQuantity,ProductImage,ProductDateAdded) VALUES ('$add_name','$add_category','$add_price','$add_quantity','$add_image','$add_date')" ;		
	   $result = mysqli_query( $link,$query) or die("Query failed");	// SQL statement for checking
         //checking either success or not
                 if ($result)
                 header("location:product.php");	
		 
		else
		 echo "Problem occured !"; 	
	    mysqli_close($link);
?>