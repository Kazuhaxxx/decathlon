<?php
include 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php
include 'head.php';
?>
<title>Admin Page</title>
</head>

<body class="bg-gradient-primary">
<?php
include 'navBar.php';
?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Adding Admin</h1>
                    </div>


                    

                    <!-- Content Row -->

                    <div class="row">

                        <div class="container-fluid">


                            <div class="card shadow mb-4">

                                <div class="card-body">
                                    <form class="admin" method="post" action="add(admin).php">
                                        <div class="form-group">
                                            Admin Name
                                            <input name="name" type="text" class="form-control form-control-user"
                                                id="name" aria-describedby="nameHelp"
                                                placeholder="Enter Admin Name...">
                                        </div>
                                        <div class="form-group">
                                            Admin Phone Number
                                            <input name="phone" type="text" class="form-control form-control-user"
                                                id="phone" placeholder="Enter Admin Phone Number...">
                                        </div>
                                        <div class="form-group">
                                            Admin Email Address
                                            <input name="email" type="email" class="form-control form-control-user"
                                                id="email" placeholder="Enter Admin Email Address...">
                                        </div>
                                        <div class="form-group">
                                            Admin Password
                                            <input name="password" type="password" class="form-control form-control-user"
                                                id="password" placeholder="Admin Password...">
                                        </div>
                                        <input type="submit" value="Add" class="btn btn-primary btn-user btn-block">
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
<?php
include 'javaScript.php';
?>

</body>

</html>