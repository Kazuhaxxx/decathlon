<?php
include 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php
include 'head.php';
?>
<title>Admin Page</title>
</head>

<body class="bg-gradient-primary">
<?php
include 'navBar.php';
?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Adding Product</h1>
                    </div>


                    

                    <!-- Content Row -->

                    <div class="row">

                        <div class="container-fluid">


                            <div class="card shadow mb-4">

                                <div class="card-body">
                                    <form class="admin" method="post" action="add(product).php">
                                        <div class="form-group">
                                            Product Name
                                            <input name="name" type="text" class="form-control form-control-user"
                                                id="name" aria-describedby="nameHelp"
                                                placeholder="Enter Product Name...">
                                        </div>
                                        <div class="form-group">
                                            Product Category
                                            <input name="category" type="text" class="form-control form-control-user"
                                                id="category" placeholder="Enter Product Category...">
                                        </div>
                                        <div class="form-group">
                                            Product Quantity
                                            <input name="quantity" type="text" class="form-control form-control-user"
                                                id="quantity" placeholder="Enter Product Quantity...">
                                        </div>
                                        <div class="form-group">
                                            Product Image
                                            <input name="image" type="text" class="form-control form-control-user"
                                                id="image" placeholder="Enter Product Image...">
                                        </div>
                                        <div class="form-group">
                                            Product Date Added
                                            <input name="date" type="datetime-local" class="form-control form-control-user"
                                                id="date">
                                        </div>
                                        <div class="form-group">
                                            Product Price
                                            <input name="price" type="text" class="form-control form-control-user"
                                                id="price" placeholder="Enter Product Price...">
                                        </div>
                                        <input type="submit" value="Add" class="btn btn-primary btn-user btn-block">
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
<?php
include 'javaScript.php';
?>

</body>

</html>