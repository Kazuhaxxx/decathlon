<?php

include 'db_connect.php';
session_start(); 							//session_start(); 							

$email = $_POST['email']; 					// assign textbox to variable
$pass = $_POST['password'];

$query = "SELECT * FROM admin where AdminEmailAddress='$email' AND AdminPassword='$pass'"; 
$result = mysqli_query( $link,$query) or die("Query failed");	// SQL statement for checking
 if(mysqli_num_rows($result) <= 0)   			// check either result found or not
	   {
		echo 'Invalid email or password.';			// redirect to another page (data not found!)
	   }
	   else
	   {
		$info = mysqli_fetch_array($result); 	// returns a row from a recordset
	    $_SESSION['name']=$info['name'];	// assign field in username to session [user]	   
		header("location:_index.html");
	   }
mysqli_close($link);
?>