<?php

$conn = mysqli_connect('localhost','root','','DecathlonSystem');

if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());
}

?>

