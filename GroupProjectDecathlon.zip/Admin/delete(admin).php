<?php 
 include 'db_connect.php';
       //delete data
       $delete_id=$_GET['admin_id']; 
	   $query = "DELETE FROM  admin WHERE AdminID='$delete_id'";
	   $result = mysqli_query( $link,$query) or die("Query failed");
       if ($result)
	   header("location:admin.php"); 
	     else
	   echo "Problem occured !"; 
	   mysqli_close($link);   
?>
