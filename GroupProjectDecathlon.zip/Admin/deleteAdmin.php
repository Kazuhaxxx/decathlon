<?php
include 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php
include 'head.php';
?>
<title>Delete Admin Page</title>
</head>

<body class="bg-gradient-primary">
<?php
include 'navBar.php';
?>
        <?php 
    //Connection to database 
    include 'db_connect.php';
    $query="Select * from admin";
    $result = mysqli_query( $link,$query) or die("Query failed");	// SQL statement for checking
    ?>
    <!-- Begin Page Content -->

    
                    <div class="container-fluid">
                      <!-- Page Heading -->
                      <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Delete Admin</h1>
                    </div>

                        <!-- DataTales Example -->
                        <div class="card shadow mb-4">

                        <div class="card-body">
                                <div class="table-responsive" style ="margin-top: 30px;">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Admin ID</th>
                                                <th>Admin Name</th>
                                                <th>Admin Phone Number</th>
                                                <th>Admin Email Address</th>
                                                <th>Remove</th>
                                            </tr>
                                        </thead>


                                        <tbody>
                                        <?php 
    //data looping
    while($row = mysqli_fetch_array($result)){ ?>
    <tr>
    <td><?php echo $row['AdminID'];?></td>
        <td><?php echo $row['AdminName'];?></td>
        <td><?php echo $row['AdminPhoneNum'];?></td>
        <td><?php echo $row['AdminEmailAddress'];?></td>
        <td><a href="delete(admin).php?admin_id=<?php print ($row['AdminID']);?>" class="btn btn-lg"><i class="fas fa-trash" style="color: #ff0000;"></i></a></td>
    </tr>
    <?php  
        // looping close
        }
        
        ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
<script>// Count the number of products
var productCount = document.querySelectorAll('tbody tr').length;

// Get the div element by class name
var countElement = document.querySelector('.h5.mb-0.font-weight-bold.text-gray-800');

// Set the product count as the inner text of the div element
countElement.innerText = productCount;
</script>

                    <!-- /.container-fluid -->
<?php
include 'javaScript.php';
?>

</body>

</html>