<?php 
 include 'db_connect.php';
 if (isset($_GET['admin_id'])) {
    $edit_id = $_GET['admin_id'];
 }
 $edit_name=$_POST['name']; 
 $edit_phone=$_POST['phone']; 
$edit_email=$_POST['email']; 
$edit_password=$_POST['password']; 
       //Update data   
	   $query="Update admin set AdminName='$edit_name', AdminPhoneNum='$edit_phone', AdminEmailAddress='$edit_email', AdminPassword='$edit_password' where AdminID='$edit_id'" ;
	   $result = mysqli_query( $link,$query) or die("Query failed");
	  
        if ($result)
		{ header("location:admin.php"); }
		   else
		{ echo "Problem occured !"; }
        mysqli_close($link);	
?>

