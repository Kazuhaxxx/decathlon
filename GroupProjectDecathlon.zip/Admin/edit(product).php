<?php 
 include 'db_connect.php';
 if (isset($_GET['product_id'])) {
    $edit_id = $_GET['product_id'];
 }
        $edit_name=$_POST['name']; 
        $edit_category=$_POST['category']; 
        $edit_price=$_POST['price']; 
        $edit_quantity=$_POST['quantity']; 
        $edit_image=$_POST['image'];
        $edit_date=$_POST['date'];
       //Update data   
	   $query="Update product set ProductName='$edit_name', ProductCategory='$edit_category', ProductPrice='$edit_price', ProductQuantity='$edit_quantity', ProductImage='$edit_image', ProductDateadded='$edit_date' where ProductID='$edit_id'" ;
	   $result = mysqli_query( $link,$query) or die("Query failed");
	  
        if ($result)
		{ header("location:product.php"); }
		   else
		{ echo "Problem occured !"; }
        mysqli_close($link);	
?>

