<?php
include 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php
include 'head.php';
?>


<title>Admin Page</title>
</head>

<body class="bg-gradient-primary">
<?php
include 'navBar.php';
?>
<?php
include 'javaScript.php';
?>
</body>

</html>
