<?php

include 'db_connect.php';
include 'config.php';

session_start();

$email = $_POST['email'];
$pass = $_POST['password'];

// Check if the entered credentials match admin credentials
$query = "SELECT * FROM admin WHERE AdminEmailAddress='$email' AND AdminPassword='$pass'";
$result = mysqli_query($link, $query) or die("Query failed");

if(mysqli_num_rows($result) > 0) {
    $info = mysqli_fetch_array($result);
    $_SESSION['AdminName'] = $info['AdminName'];
    header("location:product.php");
} else {
    // Check if the entered credentials match user credentials
    $query = "SELECT * FROM user WHERE UserEmailAddress='$email' AND UserPassword='$pass'";
    $result = mysqli_query($link, $query) or die("Query failed");

    if(mysqli_num_rows($result) > 0) {
        $info = mysqli_fetch_array($result);
        $_SESSION['UserID'] = $info['UserID'];
        header("location: ../User/indexlogin.php");
    } else {
        // Invalid email or password, display error message
        echo "<script>alert('Invalid email or password. Please try again.');</script>";
        header("location: index.html");
    }
}

mysqli_close($link);
?>
