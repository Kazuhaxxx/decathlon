<?php 
    //Connection to database 
    include 'db_connect.php';
    $query="Select * from admin";
    $result = mysqli_query( $link,$query) or die("Query failed");	// SQL statement for checking
    ?>
    <!-- Begin Page Content -->
                    <div class="container-fluid">


                        <!-- DataTales Example -->
                        <div class="card shadow mb-4">

                            <div class="card-body">
                            <a href="addAdmin.php" class="btn btn-success  btn-icon-split" style ="margin-top: 10px;">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-flag"></i>
                                        </span>
                                        <span class="text">Add Admin</span>
                                    </a>
                                    <a href="updateAdmin.php" class="btn btn-primary btn-icon-split" style ="margin-top: 10px; margin-left: 10px">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-exclamation-triangle"></i>
                                        </span>
                                        <span class="text">Update Admin</span>
                                    </a>
                                    <a href="deleteAdmin.php" class="btn btn-danger btn-icon-split" style ="margin-top: 10px; margin-left: 10px">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-trash"></i>
                                        </span>
                                        <span class="text">Delete Admin</span>
                                    </a>
                                <div class="table-responsive" style ="margin-top: 30px;">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Admin ID</th>
                                                <th>Admin Name</th>
                                                <th>Admin Phone Number</th>
                                                <th>Admin Email Address</th>
                                            </tr>
                                        </thead>


                                        <tbody>
                                        <?php 
    //data looping
    while($row = mysqli_fetch_array($result)){ ?>
    <tr>
    <td><?php echo $row['AdminID'];?></td>
        <td><?php echo $row['AdminName'];?></td>
        <td><?php echo $row['AdminPhoneNum'];?></td>
        <td><?php echo $row['AdminEmailAddress'];?></td>
    </tr>
    <?php  
        // looping close
        }
        
        ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
<script>// Count the number of products
var productCount = document.querySelectorAll('tbody tr').length;

// Get the div element by class name
var countElement = document.querySelector('.h5.mb-0.font-weight-bold.text-gray-800');

// Set the product count as the inner text of the div element
countElement.innerText = productCount;
</script>

                    <!-- /.container-fluid -->