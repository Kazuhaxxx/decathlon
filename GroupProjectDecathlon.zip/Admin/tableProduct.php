    <?php 
    //Connection to database 
    include 'db_connect.php';
    $query="Select * from product";
    $result = mysqli_query( $link,$query) or die("Query failed");	// SQL statement for checking
    ?>
    <!-- Begin Page Content -->
                    <div class="container-fluid">


                        <!-- DataTales Example -->
                        <div class="card shadow mb-4">

                            <div class="card-body">
                                 <a href="addProduct.php" class="btn btn-success  btn-icon-split" style ="margin-top: 10px;">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-flag"></i>
                                        </span>
                                        <span class="text">Add Product</span>
                                    </a>
                                    <a href="updateProduct.php" class="btn btn-primary btn-icon-split" style ="margin-top: 10px; margin-left: 10px">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-exclamation-triangle"></i>
                                        </span>
                                        <span class="text">Update Product</span>
                                    </a>
                                    <a href="deleteProduct.php" class="btn btn-danger btn-icon-split" style ="margin-top: 10px; margin-left: 10px">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-trash"></i>
                                        </span>
                                        <span class="text">Delete Product</span>
                                    </a>
                                <div class="table-responsive" style ="margin-top: 30px;">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Product ID</th>
                                                <th>Product Name</th>
                                                <th>Product Category</th>
                                                <th>Product Quantity</th>
                                                <th>Product Image</th>
                                                <th>Date Added</th>
                                                <th>Product Price</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                        <?php 
    //data looping
    while($row = mysqli_fetch_array($result)){ ?>
    <tr>
    <td><?php echo $row['ProductID'];?></td>
        <td><?php echo $row['ProductName'];?></td>
        <td><?php echo $row['ProductCategory'];?></td>
        <td><?php echo $row['ProductQuantity'];?></td>
        <td><img src="productImg/<?php echo $row['ProductImage'];?>" alt="" style=" width: 75px;"></td>
        <td><?php echo $row['ProductDateAdded'];?></td>
        <td>$<?php echo $row['ProductPrice'];?></td>
    </tr>
    <?php  
        // looping close
        }
        
        ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
<script>// Count the number of products
var productCount = document.querySelectorAll('tbody tr').length;

// Get the div element by class name
var countElement = document.querySelector('.h5.mb-0.font-weight-bold.text-gray-800');

// Set the product count as the inner text of the div element
countElement.innerText = productCount;
</script>

                    <!-- /.container-fluid -->