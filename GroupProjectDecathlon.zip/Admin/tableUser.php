<?php 
    //Connection to database 
    include 'db_connect.php';
    $query="Select * from user";
    $result = mysqli_query( $link,$query) or die("Query failed");	// SQL statement for checking
    ?>
    <!-- Begin Page Content -->
                    <div class="container-fluid">


                        <!-- DataTales Example -->
                        <div class="card shadow mb-4">

                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>User ID</th>
                                                <th>User Email Address</th>
                                                <th>User Password</th>
                                                <th>User First Name</th>
                                                <th>User Last Name</th>
                                                <th>User Birth of Date</th>
                                                <th>User Phone Number</th>
                                                <th>User Gender</th>
                                                <th>User Address</th>
                                            </tr>
                                        </thead>


                                        <tbody>
                                        <?php 
    //data looping
    while($row = mysqli_fetch_array($result)){ ?>
    <tr>
        <td><?php echo $row['UserID'];?></td>
        <td><?php echo $row['UserEmailAddress'];?></td>
        <td><?php echo $row['UserPassword'];?></td>
        <td><?php echo $row['UserFirstName'];?></td>
        <td><?php echo $row['UserLastName'];?></td>
        <td><?php echo $row['UserBirthDate'];?></td>
        <td><?php echo $row['UserPhoneNum'];?></td>
        <td><?php echo $row['UserGender'];?></td>
        <td><?php echo $row['UserAddress'];?></td>
    </tr>
    <?php  
        // looping close
        }
        
        ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
<script>// Count the number of products
var productCount = document.querySelectorAll('tbody tr').length;

// Get the div element by class name
var countElement = document.querySelector('.h5.mb-0.font-weight-bold.text-gray-800');

// Set the product count as the inner text of the div element
countElement.innerText = productCount;
</script>

                    <!-- /.container-fluid -->