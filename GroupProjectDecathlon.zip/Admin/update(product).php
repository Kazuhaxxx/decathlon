
<?php 
    include 'db_connect.php';
        
    $id=$_GET['product_id'];
    $query="SELECT * FROM  product WHERE ProductID='$id'";
    $result = mysqli_query( $link,$query) or die("Query failed");	// SQL statement for checking
                    
?>
<?php while ( $user = mysqli_fetch_array( $result ))
{
                $id=$user['ProductID'];
                $name=$user['ProductName'];
                $category=$user['ProductCategory'];
                $quantity=$user['ProductQuantity'];
                $img=$user['ProductImage'];
                $date=$user['ProductDateAdded'];
                $price=$user['ProductPrice'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php
include 'head.php';
?>
<title>Admin Page</title>
</head>

<body class="bg-gradient-primary">
<?php
include 'navBar.php';
?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Update Product</h1>
                    </div>


                    

                    <!-- Content Row -->

                    <div class="row">

                        <div class="container-fluid">


                            <div class="card shadow mb-4">

                                <div class="card-body">
                                    <form class="admin" method="post" action="edit(product).php?product_id=<?php echo $id;?>">

                                        <div class="form-group">
                                            Product Name
                                            <input name="name" type="text" class="form-control form-control-user"
                                                id="name" aria-describedby="nameHelp"
                                                 value="<?php echo $name ?>">
                                        </div>
                                        <div class="form-group">
                                            Product Category
                                            <input name="category" type="text" class="form-control form-control-user"
                                                id="category" value="<?php echo $category ?>">
                                        </div>
                                        <div class="form-group">
                                            Product Quantity
                                            <input name="quantity" type="text" class="form-control form-control-user"
                                                id="quantity"  value="<?php echo $quantity ?>">
                                        </div>
                                        <div class="form-group">
                                            Product Image
                                            <input name="image" type="text" class="form-control form-control-user"
                                                id="image"  value="<?php echo $img ?>">
                                        </div>
                                        <div class="form-group">
                                            Product Date Added
                                            <input name="date" type="datetime-local" class="form-control form-control-user"
                                                id="date" value="<?php echo $date ?>">
                                        </div>
                                        <div class="form-group">
                                            Product Price
                                            <input name="price" type="text" class="form-control form-control-user"
                                                id="price" value="<?php echo $price ?>">
                                        </div>
                                        <input type="submit" value="Save" class="btn btn-primary btn-user btn-block">
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
<?php
include 'javaScript.php';
?>

</body>

</html>