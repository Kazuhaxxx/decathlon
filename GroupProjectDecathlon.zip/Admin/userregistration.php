<?php
@include 'config.php';

if(isset($_POST['submit'])) {
   $UserEmailAddress = mysqli_real_escape_string($conn, $_POST['UserEmailAddress']);
   $UserPassword = mysqli_real_escape_string($conn, $_POST['UserPassword']);
   $cpass = mysqli_real_escape_string($conn, $_POST['cpassword']);
   $UserFirstName = mysqli_real_escape_string($conn, $_POST['UserFirstName']);
   $UserLastName = mysqli_real_escape_string($conn, $_POST['UserLastName']);
   $UserPhoneNum = mysqli_real_escape_string($conn, $_POST['UserPhoneNum']);
   $UserBirthDate = $_POST['UserBirthDate'];
   $UserGender = $_POST['UserGender'];
   $UserAddress = mysqli_real_escape_string($conn, $_POST['UserAddress']);

   $select = "SELECT * FROM user WHERE UserEmailAddress = '$UserEmailAddress'";
   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0) {
      $error[] = 'User already exists!';
   } else {
      if($UserPassword != $cpass) {
         $error[] = 'Passwords do not match!';
      } else {
         $insert = "INSERT INTO user(UserEmailAddress, UserPassword, UserFirstName, UserLastName, UserPhoneNum, UserBirthDate, UserGender, UserAddress) VALUES ('$UserEmailAddress','$UserPassword','$UserFirstName','$UserLastName','$UserPhoneNum','$UserBirthDate','$UserGender','$UserAddress')";
         mysqli_query($conn, $insert);
         $userID = mysqli_insert_id($conn);

         $insertCart = "INSERT INTO cart(UserID) VALUES ('$userID')";
         mysqli_query($conn, $insertCart);
         $cartID = mysqli_insert_id($conn);


         header('location:index.php');
      }
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<style>
   @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

*{
   font-family: 'Poppins', sans-serif;
   margin:0; padding:0;
   box-sizing: border-box;
   outline: none; border:none;
   text-decoration: none;
}

.faded-text {
   opacity: 0.3;
}

.centered-input {
   text-align: center;
}

.container{
   min-height: 100vh;
   display: flex;
   align-items: center;
   justify-content: center;
   padding:20px;
   padding-bottom: 60px;
}

.container .content{
   text-align: center;
}

.container .content h3{
   font-size: 30px;
   color:#333;
}

.container .content h3 span{
   background: crimson;
   color:#fff;
   border-radius: 5px;
   padding:0 15px;
}

.container .content h1{
   font-size: 50px;
   color:#333;
}

.container .content h1 span{
   color:crimson;
}

.container .content p{
   font-size: 25px;
   margin-bottom: 20px;
}

.container .content .btn{
   display: inline-block;
   padding:10px 30px;
   font-size: 20px;
   background: #333;
   color:#fff;
   margin:0 5px;
   text-transform: capitalize;
}

.container .content .btn:hover{
   background: crimson;
}

.form-container{
   min-height: 100vh;
   display: flex;
   align-items: center;
   justify-content: center;
   padding:20px;
   padding-bottom: 60px;
   background: #eee;
}

.form-container form{
   padding:20px;
   border-radius: 5px;
   box-shadow: 0 5px 10px rgba(0,0,0,.1);
   background: #fff;
   text-align: center;
   width: 500px;
}

.form-container form h3{
   font-size: 30px;
   text-transform: uppercase;
   margin-bottom: 10px;
   color:#333;
}

.form-container form input,
.form-container form select{
   width: 100%;
   padding:10px 15px;
   font-size: 17px;
   margin:8px 0;
   background: #eee;
   border-radius: 5px;
}

.form-container form select option{
   background: #fff;
}

.form-container form .form-btn{
   background: #fbd0d9;
   color:crimson;
   text-transform: capitalize;
   font-size: 20px;
   cursor: pointer;
}

.form-container form .form-btn:hover{
   background: crimson;
   color:#fff;
}

.form-container form p{
   margin-top: 10px;
   font-size: 20px;
   color:#333;
}

.form-container form p a{
   color:crimson;
}

.form-container form .error-msg{
   margin:10px 0;
   display: block;
   background: crimson;
   color:#fff;
   border-radius: 5px;
   font-size: 20px;
   padding:10px;
}
</style>
<body>
<div class="form-container">
   <form action="" method="post">
      <h3>User Registration</h3>
      <?php
      if(isset($error)) {
         foreach($error as $error) {
            echo '<span class="error-msg">'.$error.'</span>';
         }
      }
      ?>
      <input type="email" name="UserEmailAddress" required placeholder="Enter your email">
      <input type="password" name="UserPassword" required placeholder="Enter your password">
      <input type="password" name="cpassword" required placeholder="Confirm your password">
      <input type="text" name="UserFirstName" required placeholder="Enter your first name">
      <input type="text" name="UserLastName" required placeholder="Enter your last name">
      <input type="text" name="UserPhoneNum" required placeholder="Enter your phone number">
      <input type="date" name="UserBirthDate" required placeholder="Select your date of birth">
      <select name="UserGender" required>
         <option value="male">Male</option>
         <option value="female">Female</option>
      </select>
      <input type="text" name="UserAddress" required placeholder="Enter your address">

      <input type="submit" name="submit" value="Register Now" class="form-btn">
      <p>Already have an account? <a href="index.php">Login Now</a></p>
   </form>
</div>
</body>
</html>
